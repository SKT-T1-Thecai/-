import json
import os
import time
from datetime import datetime
from django.db.models import F, Q
from django.http import HttpResponse, JsonResponse, FileResponse, Http404, StreamingHttpResponse
from django.shortcuts import render
from django.utils import timezone
from django.utils.encoding import escape_uri_path
from django.shortcuts import redirect
from .models import user, post, postphoto, subject, thumbup, comment, sharefile

# Create your views here.

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
up = MEDIA_ROOT = os.path.join(BASE_DIR, 'uploads')


def gg(request):
    return HttpResponse("sunkman")


def login(request):
    name = request.session.get('name', "")
    password = request.session.get('password', "")
    request.session['User']=""
    return render(request, 'login.html', locals())


def main(request):  # 判断id和密码，符合就进入主页，否则继续登录
    if request.method == 'POST':
        sta = 1
        name = request.POST.get('name', "")
        password = request.POST.get('password', "")
        u = user.objects.filter(uname=name)
        if u and u[0].upassword == password:  # 合法的用户
            request.session['name'] = ""
            request.session['password'] = ""
            User = request.session.get('User', "null")
            User = name
            request.session['User'] = User
            u = user.objects.get(uname=User)
            c = int(datetime.now().strftime("%y%m%d"))
            d = int(u.lastlogintime.strftime("%y%m%d"))
            # print(abs(c-d))
            if abs(c - d) >= 1:
                u.uexp += 10
                u.lastlogintime = datetime.now()
                if u.uexp >= 90 + 10 * u.ulevel:
                    u.uexp = u.uexp - (90 + 10 * u.ulevel)
                    u.ulevel += 1;
                u.save()
            return render(request, 'main.html', locals())
        else:
            tips = "用户名或密码错误，请重试！"
            return render(request, 'login.html', locals())
    elif request.session.get('User', "") == "":
        sta = 0
        request.session['tourist'] = "tourist"
        request.session['name'] = ""
        request.session['password'] = ""
        return render(request, 'main.html', locals())
    else:
        User = request.session['User']
        u = user.objects.get(uname=User)
        request.session['name'] = ""
        request.session['password'] = ""
        return render(request, 'main.html', locals())


def register(request):
    return render(request, 'register.html')


def myinfo(request):
    if request.session.get('User', "") == "":
        return HttpResponse("游客无法访问个人信息，请登录！")
    User = request.session.get('User')
    r = user.objects.get(uname=User)
    rid = r.id
    rname = r.uname
    rgender = r.ugender
    rlevel = r.ulevel
    rage = r.uage
    rphoto = r.uphoto
    rexp = r.uexp
    remail = r.uemail
    rintro = r.uintroduce
    rforbidden = r.isForbidden
    rlimit = 90 + 10 * rlevel
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    postlist = post.objects.filter(puser_id=rid)
    if rgender == 1:
        rgender = "男"
    else:
        rgender = "女"
    if rforbidden == True:
        rforbidden = "由于您的不良行为，您已被禁止发帖，评论"
    else:
        rforbidden = "允许发帖，评论"
    return render(request, 'myinfo.html', locals())


def judgeinfo(request):  # 判断注册信息是否合法
    name = request.POST.get('name',"")
    email = request.POST.get('email',"")
    gender = request.POST.get('gender')
    age = request.POST.get('age')
    password = request.POST.get('password')
    repassword = request.POST.get('repassword')
    if user.objects.filter(uname=name).count():  # 不为0
        tips = "用户名已存在，请更改用户名！"
        return render(request, 'register.html', locals())
    elif name == "":
        tips = "用户名不能为空！"
        return render(request, 'register.html', locals())
    elif not iflegalpasswd(password):
        tips = "密码必须不少于8位，并且至少同时含有字母和数字！"
        return render(request, 'register.html', locals())
    elif password!=repassword:
        tips="两次密码输入必须一致！"
        return render(request, 'register.html', locals())
    elif age< 0:
        tips="年龄不能为负数！"
        return render(request, 'register.html', locals())
    else:

        u = user()
        u.uname = name
        u.uage = age
        u.upassword = password
        u.ugender = gender
        u.uemail = email
        u.lastlogintime = datetime.now()
        u.save()
        request.session['name'] = name
        request.session['password'] = password
        return redirect('/')


def changeinfo(request):
    User = request.session.get('User')
    r = user.objects.get(uname=User)
    rname = r.uname
    rgender = r.ugender
    rlevel = r.ulevel
    rage = r.uage
    rexp = r.uexp
    remail = r.uemail
    rintro = r.uintroduce
    rforbidden = r.isForbidden
    rlimit = 90 + 10 * rlevel
    if rgender == 1:
        rgender = "男"
        xb = True
    else:
        rgender = "女"
        xb = False
    if rforbidden == True:
        rforbidden = "由于您的不良行为，您已被禁止发帖，评论"
    else:
        rforbidden = "允许发帖，评论"
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    return render(request, 'changeinfo.html', locals())


def mainjudgeinfo(request):
    imagefile = request.FILES.get('photo', None)
    newname = request.POST.get('name')
    age = request.POST.get('age')
    gender = request.POST.get('gender')
    intro = request.POST.get('intro')
    email = request.POST.get('email')
    name = request.session.get('User')
    if name != newname and user.objects.filter(uname=newname):
        tips = "用户名" + '"' + newname + '"' + "已存在！"
        return render(request, 'changeinfo.html', locals())
    u = user.objects.get(uname=name)  # 更改信息
    u.uname = newname
    u.uemail = email
    u.uage = age
    u.ugender = gender
    if imagefile is not None:
        # f = open(os.path.join(up + "\\uphoto", imagefile.name), 'wb+')
        # for chunk in imagefile.chunks():
        #     f.write(chunk)
        # f.close()
        if (u.uphoto != "uphoto/default.jpg"):
            u.uphoto.delete()
        u.uphoto = imagefile
    u.uintroduce = intro
    u.save()
    request.session['User'] = newname  # 更新session
    r = user.objects.get(uname=newname)
    rname = r.uname
    rgender = r.ugender
    rlevel = r.ulevel
    rexp = r.uexp
    rage = r.uage
    remail = r.uemail
    rintro = r.uintroduce
    rforbidden = r.isForbidden
    rlimit = 90 + 10 * rlevel
    if rgender == 1:
        rgender = "男"
    else:
        rgender = "女"
    if rforbidden == True:
        rforbidden = "由于您的不良行为，您已被禁止发帖，评论"
    else:
        rforbidden = "允许发帖，评论"
    return render(request, 'myinfo.html', locals())


def changepassword(request):
    return render(request, 'changepassword.html')


def iflegalpasswd(string):
    a = False
    b = False
    d = False
    for c in string:
        if c.isalpha():
            a = True
        if c.isnumeric():
            b = True
    if len(string) >= 8:
        d = True
    return a and b and d


def judgepassword(request):
    oldpassword = request.POST.get('oldpassword')
    newpassword = request.POST.get('newpassword')
    renewpassword = request.POST.get('renewpassword')
    name = request.session.get('User')
    u = user.objects.get(uname=name)
    if u.upassword != oldpassword:
        tips = "原密码输入错误，请重试！"
        return render(request, 'changepassword.html', locals())
    elif not iflegalpasswd(newpassword):
        tips = "密码必须不少于8位，并且至少同时含有字母和数字！"
        return render(request, 'changepassword.html', locals())
    elif newpassword != renewpassword:
        tips = "新密码和确认密码必须相等！"
        return render(request, 'changepassword.html', locals())
    else:
        u.upassword = newpassword
        u.save()
        return HttpResponse("密码修改成功，请重新登陆！")


def discussarea(request):  # 讨论区界面，需要显示帖子
    if request.session.get('User', "") != "":
        name = request.session.get('User')
        u = user.objects.get(uname=name)
    postlist = post.objects.filter(ptype="discuss").order_by("-pcreatetime")
    ifp = []
    j = 0
    pos = 0
    for p in postlist:
        p.pcreatetime = p.pcreatetime.strftime('%Y-%m-%d %X')
        if len(p.pcontend) > 500:
            p.pcontend = p.pcontend[0:500] + "..."
        else:
            p.pcontend = p.pcontend[0:500]
        if request.session.get('User', "") != "" and thumbup.objects.filter(user=u).filter(post=p):
            ifp.append(p.id)
    return render(request, 'discussarea.html', locals())


def dispost(request):  # 讨论区发帖界面
    if request.session.get('User', "") == "":
        return HttpResponse("游客无法发帖，请登录！")
    name = request.session.get('User')
    u = user.objects.get(uname=name)
    if u.isForbidden == True:
        return HttpResponse("由于您的不良行为，您已被禁止发帖，评论，请联系7777777@qq.com进行解封！")
    return render(request, 'dispost.html', locals())


def filetype(filename):
    pos = len(filename)
    while pos >= 0:
        pos -= 1
        if filename[pos] == '.':
            break;
    type = filename[pos + 1:]
    if type.lower() == "mp4" or type.lower() == "avi" or type.lower() == "asf" or type.lower() == "rm" or type.lower() == "navi":
        return "video"
    else:
        return "picture"


def disjudgepost(request):
    file = request.FILES.getlist('file', None)
    title = request.POST.get('title')
    body = request.POST.get('body')
    limit = request.POST.get('iflimit', False)
    r = post()
    r.ptitle = title
    r.pcontend = body
    r.ptype = "discuss"
    r.limitolowlevel = limit
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    r.puser_id = u.id
    r.save()
    u.uexp += 10
    if u.uexp >= 90 + 10 * u.ulevel:
        u.uexp = u.uexp - (90 + 10 * u.ulevel)
        u.ulevel += 1;
    u.save()
    for i in file:
        q = postphoto()
        q.photo = i
        q.post_id = r.id
        fn = str(i)
        q.ptype = filetype(fn)
        q.save()
    return HttpResponse('发布成功')


def viewpost(request, pid):
    if request.session.get('User', "") == "":
        return HttpResponse("游客无法查看帖子的详细信息，请登录！")
    name = request.session.get('User')
    u = user.objects.get(uname=name)
    po = post.objects.get(id=pid)
    if po.limitolowlevel == True and u.ulevel < 10:
        return HttpResponse("帖子的主人设置了权限，必须大于等于10级才能查看哦，快去升级吧！")
    if po.ptype == "discuss":
        i = 1
    elif po.ptype == "subject":
        i = 2
    elif po.ptype == "around":
        i = 3
    elif po.ptype == "lessonintro":
        i = 4
    photolist = postphoto.objects.filter(post_id=po.id)
    commentlist = comment.objects.filter(cpost_id=pid)
    return render(request, 'viewpost.html', locals())


def subjectarea(request):
    if request.session.get('User', "") != "":
        name = request.session.get('User')
        u = user.objects.get(uname=name)
    postlist = post.objects.filter(ptype="subject").order_by("-pcreatetime")
    ifp = []
    j = 0
    pos = 0
    for p in postlist:
        p.pcreatetime = p.pcreatetime.strftime('%Y-%m-%d %X')
        if len(p.pcontend) > 500:
            p.pcontend = p.pcontend[0:500] + "..."
        else:
            p.pcontend = p.pcontend[0:500]
        if request.session.get('User', "") != "" and thumbup.objects.filter(user=u).filter(post=p):
            ifp.append(p.id)
    return render(request, 'subject.html', locals())


def viewsubject(request, sid):
    sub = subject.objects.get(id=sid)
    return render(request, 'viewsubject.html', locals())


def like(request):
    uid = request.GET.get('uid')
    pid = request.GET.get('pid')
    po = post.objects.get(id=pid)
    op = {}
    if thumbup.objects.filter(user_id=uid).filter(post_id=pid):
        op['status'] = 'ever'
        po.pprasingnum -= 1
        po.save()
        thumbup.objects.filter(user_id=uid).filter(post_id=pid)[0].delete()
        op['num'] = po.pprasingnum
        op['tip'] = "取消赞成功！"
        return JsonResponse(op)
    else:
        t = thumbup()
        t.post_id = pid
        t.user_id = uid
        u = user.objects.get(id=uid)
        u.uexp += 10
        if u.uexp >= 90 + 10 * u.ulevel:
            u.uexp = u.uexp - (90 + 10 * u.ulevel)
            u.ulevel += 1;
        u.save()
        t.save()
        po.pprasingnum += 1
        po.save()
        u1 = user.objects.get(id=po.puser.id)
        u1.uexp += 10
        if u1.uexp >= 90 + 10 * u1.ulevel:
            u1.uexp = u1.uexp - (90 + 10 * u1.ulevel)
            u1.ulevel += 1;
        u1.save()
        op = {}
        op['status'] = 'success'
        op['num'] = po.pprasingnum
        op['tip'] = "点赞成功"
        return JsonResponse(op)


def tocomment(request):
    uid = request.GET.get('uid')
    pid = request.GET.get('pid')
    u = user.objects.get(id=uid)
    op = {}
    if u.isForbidden == True:
        op['status'] = 'success'
        op['tip'] = "由于您的不良行为，您已被禁止发帖，评论，请联系7777777@qq.com进行解封！"
        return JsonResponse(op)

    po = post.objects.get(id=pid)
    contend = request.GET.get('contend')
    comm = comment()
    comm.cuser_id = uid
    comm.cpost_id = pid
    comm.ccontend = contend
    comm.save()

    u.uexp += 30
    if u.uexp >= 90 + 10 * u.ulevel:
        u.uexp = u.uexp - (90 + 10 * u.ulevel)
        u.ulevel += 1;
    u.save()
    po.pcommentnum += 1
    po.save()

    op['status'] = 'success'
    op['tip'] = "评论成功"
    return JsonResponse(op)


def share(request):
    if request.session.get('User', "") == "":
        return HttpResponse("游客无法上传或下载资源，请登录！")
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    return render(request, 'share.html', locals())


def upload(request):
    sta = 0
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    return render(request, 'uploadfile.html', locals())


def savefile(request):
    filename = request.POST.get('filename', "")
    filepath = request.POST.get('filepath', "")
    file = request.FILES.get('file', None)
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    if filename == "" or (filepath == "" and file is None):
        tips = "文件名必须填写，文件地址和文件上传不能同时为空！"
        sta = 2
        return render(request, 'uploadfile.html', locals())
    if sharefile.objects.filter(suser_id=u.id).filter(filename=filename):
        tips = "你已经上传过同名文件，请更改文件名重新上传"
        sta = 2
        return render(request, 'uploadfile.html', locals())
    sf = sharefile()
    sf.filename = filename
    sf.filepath = filepath
    sf.file = file
    sf.suser = u
    sf.fuploadtime = datetime.now()
    sf.save()
    tips = "上传成功，你可以继续上传！"
    sta = 1
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    return render(request, 'uploadfile.html', locals())


def filesearchtip(request):
    key = request.GET.get('key')
    tips = {}
    qset = sharefile.objects.filter(filename__icontains=key)
    nameset = []
    for i in qset:
        nameset.append(i.filename)
    tips['res'] = ','.join([str(i) for i in nameset])
    tips['status'] = 'success'
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    return JsonResponse(tips)


def searchfile(request):
    key = request.POST.get('key', "请输入关键字")
    filelist = sharefile.objects.filter(filename__icontains=key)  # i代表忽略大小写
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    return render(request, 'share.html', locals())


def downloadfile(request, fid):
    f = sharefile.objects.get(id=fid)
    fpath = "D:\\02.png"
    fpath = str(MEDIA_ROOT) + "\\" + str(f.file).replace('/', "\\")
    # print(fpath)
    # filename = str(f.file)[10:]
    # print(filename)
    # f = open(fpath,'rb')
    # data = f.read()
    # f.close()
    # # 以下设置项是为了下载任意类型文件
    # response = HttpResponse(data, content_type='application/octet-stream')
    # response['Content-Disposition'] = 'attachment; filename=%s' % filename
    # print(response['Content-Disposition'])
    # return response
    return download_file(request, fpath)


def download_file(request, file_path):
    file_name = os.path.basename(file_path)
    print(file_path)
    if not os.path.isfile(file_path):
        return HttpResponse(file_name)

    def file_iterator(tar_file_path, chunk_size=512):
        with open(tar_file_path, mode='rb') as file:
            while True:
                content = file.read(chunk_size)
                if content:
                    yield content
                else:
                    break

    try:
        response = StreamingHttpResponse(file_iterator(file_path))
        response['Content-Type'] = 'application/octet-stream'
        response["Content-Disposition"] = "attachment; filename*=UTF-8''{}".format(escape_uri_path(file_name))
    except:
        return HttpResponse("Sorry but Not Found the File")

    return response


def viewuser(request, uid):
    u = user.objects.get(id=uid)
    postlist = post.objects.filter(puser_id=uid)
    return render(request, 'viewuser.html', locals())


def subjectstack(request):
    subjectlist = subject.objects.all()
    return render(request, 'subjectstack.html', locals())


def postforsub(request, sid):
    if request.session.get('User', "") == "":
        return HttpResponse("游客无法发帖，请登录！")
    sub = subject.objects.get(id=sid)
    name = request.session.get('User')
    u = user.objects.get(uname=name)
    if u.isForbidden == True:
        return HttpResponse("由于您的不良行为，您已被禁止发帖，评论，请联系7777777@qq.com进行解封！")
    return render(request, 'postforsub.html', locals())


def subsavepost(request, sid):
    file = request.FILES.getlist('file', None)
    title = request.POST.get('title')
    body = request.POST.get('body')
    r = post()
    r.ptitle = title
    r.pcontend = body
    r.ptype = "subject"
    r.psub = subject.objects.get(id=sid)
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    r.puser = u
    r.save()
    for i in file:
        q = postphoto()
        q.photo = i
        q.post_id = r.id
        fn = str(i)
        q.ptype = filetype(fn)
        q.save()
    # return HttpResponse("发帖成功！")
    return redirect('/main/subject')


def around(request):
    if request.session.get('User', "") != "":
        name = request.session.get('User')
        u = user.objects.get(uname=name)
    postlist = post.objects.filter(ptype="around").order_by("-pcreatetime")
    ifp = []
    j = 0
    pos = 0
    for p in postlist:
        p.pcreatetime = p.pcreatetime.strftime('%Y-%m-%d %X')
        if len(p.pcontend) > 500:
            p.pcontend = p.pcontend[0:500] + "..."
        else:
            p.pcontend = p.pcontend[0:500]
        if request.session.get('User', "") != "" and thumbup.objects.filter(user=u).filter(post=p):
            ifp.append(p.id)
    return render(request, 'around.html', locals())


def postforaround(request):
    if request.session.get('User', "") == "":
        return HttpResponse("游客无法发帖，请登录！")
    name = request.session.get('User')
    u = user.objects.get(uname=name)
    if u.isForbidden == True:
        return HttpResponse("由于您的不良行为，您已被禁止发帖，评论，请联系7777777@qq.com进行解封！")
    return render(request, 'postforaround.html', locals())


def savepost(request):
    file = request.FILES.getlist('file', None)
    title = request.POST.get('title')
    body = request.POST.get('body')
    limit = request.POST.get('iflimit', False)
    r = post()
    r.ptitle = title
    r.pcontend = body
    r.ptype = "around"
    r.limitolowlevel = limit
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    r.puser_id = u.id
    r.save()
    u.uexp += 10
    if u.uexp >= 90 + 10 * u.ulevel:
        u.uexp = u.uexp - (90 + 10 * u.ulevel)
        u.ulevel += 1;
    u.save()
    for i in file:
        q = postphoto()
        q.photo = i
        q.post_id = r.id
        fn = str(i)
        q.ptype = filetype(fn)
        q.save()
    return HttpResponse('发布成功')


def lessonintro(request):
    if request.session.get('User', "") != "":
        name = request.session.get('User')
        u = user.objects.get(uname=name)
    postlist = post.objects.filter(ptype="lessonintro").order_by("-pcreatetime")
    ifp = []
    j = 0
    pos = 0
    for p in postlist:
        p.pcreatetime = p.pcreatetime.strftime('%Y-%m-%d %X')
        if len(p.pcontend) > 500:
            p.pcontend = p.pcontend[0:500] + "..."
        else:
            p.pcontend = p.pcontend[0:500]
        if request.session.get('User', "") != "" and thumbup.objects.filter(user=u).filter(post=p):
            ifp.append(p.id)
    return render(request, 'lessonintro.html', locals())


def postforlesson(request):
    if request.session.get('User', "") == "":
        return HttpResponse("游客无法发帖，请登录！")
    name = request.session.get('User')
    u = user.objects.get(uname=name)
    if u.isForbidden == True:
        return HttpResponse("由于您的不良行为，您已被禁止发帖，评论，请联系7777777@qq.com进行解封！")
    return render(request, 'postforlesson.html', locals())


def savepostforintro(request):
    file = request.FILES.getlist('file', None)
    title = request.POST.get('title')
    body = request.POST.get('body')
    limit = request.POST.get('iflimit', False)
    coursename = request.POST.get('coursename', False)
    courselink = request.POST.get('courselink', False)
    r = post()
    r.ptitle = title
    r.pcontend = body
    r.ptype = "lessonintro"
    r.limitolowlevel = limit
    r.coursename = coursename
    r.courselink = courselink
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    r.puser_id = u.id
    r.save()
    u.uexp += 10
    if u.uexp >= 90 + 10 * u.ulevel:
        u.uexp = u.uexp - (90 + 10 * u.ulevel)
        u.ulevel += 1;
    u.save()
    for i in file:
        q = postphoto()
        q.photo = i
        q.post_id = r.id
        fn = str(i)
        q.ptype = filetype(fn)
        q.save()
    return HttpResponse('发布成功')


def searchp(request):
    key = request.POST.get('key')
    if request.session.get('User', "") != "":
        name = request.session.get('User')
        u = user.objects.get(uname=name)
    pl = post.objects.filter(Q(ptitle__icontains=key) | Q(pcontend__icontains=key))
    ifp = []
    j = 0
    pos = 0
    for p in pl:
        p.pcreatetime = p.pcreatetime.strftime('%Y-%m-%d %X')
        if len(p.pcontend) > 500:
            p.pcontend = p.pcontend[0:500] + "..."
        else:
            p.pcontend = p.pcontend[0:500]
        if request.session.get('User', "") != "" and thumbup.objects.filter(user=u).filter(post=p):
            ifp.append(p.id)
    return render(request, 'searchpost.html', locals())
