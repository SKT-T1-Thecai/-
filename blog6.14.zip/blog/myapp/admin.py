from django.contrib import admin
from .models import user, post, comment, postphoto,subject

# Register your models here.
admin.site.register(user)
admin.site.register(post)
admin.site.register(comment)
admin.site.register(postphoto)
admin.site.register(subject)
