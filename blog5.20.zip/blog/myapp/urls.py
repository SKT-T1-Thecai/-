from django.conf import settings
from django.conf.urls import url
from django.contrib import admin
from django.template.context_processors import static
from django.urls import path, include, re_path

from . import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('gg/', views.gg),
    path('', views.login,name='login'),
    path('main/', views.main,name='main'),
    path('register/', views.register, name='register'),
    path('myinfo/',views.myinfo,name='myinfo'),
    path('register/judgeinfo/',views.judgeinfo),
    path('login/',views.login),
    path('main/changeinfo',views.changeinfo,name="changeinfo"),
    path('main/judgeinfo',views.mainjudgeinfo),
    path('main/changepassword', views.changepassword,name="changepassword"),
    path('main/judgepassword', views.judgepassword,name="judgepassword"),
    path('main/discussarea', views.discussarea,name="discussarea"),
    path('main/dispost', views.dispost,name="dispost"),
    path('main/dispost/judgepost',views.disjudgepost,name="disjudgepost"),
    path('main/viewpost/<int:pid>',views.viewpost,name="viewpost"),
    path('main/subject',views.subjectarea,name="subject"),
    path('main/subject/<int:sid>',views.viewsubject,name="viewsubject"),
    path('like/',views.like,name="like"),
    path('comment/',views.tocomment,name="comment"),
    path('main/share',views.share,name="share"),
    path('main/share/upload',views.upload,name="upload"),
    path('main/share/savefile',views.savefile,name="savefile"),
    path('main/share/search',views.searchfile,name="searchfile"),
    path('filesearchtip/',views.filesearchtip,name="filesearchtip"),
    path('downloadfile/<int:fid>',views.downloadfile,name="downloadfile"),
    path('user/<int:uid>',views.viewuser,name="viewuser"),
    path('main/subject/subjectstack',views.subjectstack,name="subjectstack"),
    path('main/subject/postforsub/<int:sid>',views.postforsub,name="postforsub"),
    path('main/subject/subsavepost/<int:sid>',views.subsavepost,name="subsavepost"),

]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)