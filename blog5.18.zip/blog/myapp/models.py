from django.db import models


# Create your models here.
class user(models.Model):
    uname = models.CharField(max_length=20)  # 昵称
    ugender = models.BooleanField(default=False)  # 性别
    uage = models.IntegerField(default=0)  # 年龄
    ulevel = models.IntegerField(default=1)  # 等级
    uexp = models.IntegerField(default=0)  # 经验
    uemail = models.EmailField(default="")
    uintroduce = models.CharField(max_length=200)  # 简介
    uphoto = models.ImageField(upload_to="uphoto/", default="uphoto/default.jpg")  # 头像
    upassword = models.CharField(max_length=20)
    isForbidden = models.BooleanField(default=False)

    def __str__(self):
        return self.uname


class post(models.Model):
    puser = models.ForeignKey(user, on_delete=models.CASCADE)
    ptitle = models.CharField(max_length=50)  # 标题
    pcontend = models.TextField(default="")  # 内容
    ptype = models.CharField(max_length=50)  # 类型：simple,subject,campus,class,sharefile
    pstart = models.TextField(default="")  # 开头一部分
    pprasingnum = models.IntegerField(default=0)  # 点赞数
    pcommentnum = models.IntegerField(default=0)  # 评论数
    pcreatetime = models.DateTimeField(auto_now_add=True)
    limitolowlevel = models.BooleanField(default=False)

    def __str__(self):
        return self.ptitle


class comment(models.Model):
    ccontend = models.CharField(max_length=200)  # 评论内容
    cpost = models.ForeignKey(post, on_delete=models.CASCADE)  # 帖子
    cuser = models.ForeignKey(user, on_delete=models.CASCADE)  # 用户
    ccreatetime = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.ccontend


class postphoto(models.Model):
    post = models.ForeignKey(post, on_delete=models.CASCADE)
    ptype = models.CharField(max_length=100, default="")
    photo = models.FileField(upload_to="postphoto/")
    photoname = models.CharField(max_length=100)


class subject(models.Model):
    title = models.CharField(max_length=200, default="")
    contend = models.TextField(default="")
    subjectphoto = models.ImageField(null=True, blank=True, upload_to="subjectphoto/")

    def __str__(self):
        return self.title


class thumbup(models.Model):
    user = models.ForeignKey(user, on_delete=models.CASCADE)
    post = models.ForeignKey(post, on_delete=models.CASCADE)


class sharefile(models.Model):
    file = models.FileField(upload_to="sharefile/", null=True, blank=True)
    suser = models.ForeignKey(user, on_delete=models.CASCADE)
    filepath = models.CharField(max_length=500, default="")
    filename = models.CharField(max_length=200)
    fuploadtime = models.DateTimeField(auto_now_add=False, default="2020-05-08 09:22:16.786247")
