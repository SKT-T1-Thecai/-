import json
import os
from datetime import datetime

from django.http import HttpResponse, JsonResponse, FileResponse, Http404, StreamingHttpResponse
from django.shortcuts import render
from django.utils.encoding import escape_uri_path

from .models import user, post, postphoto, subject, thumbup, comment, sharefile

# Create your views here.

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
up = MEDIA_ROOT = os.path.join(BASE_DIR, 'uploads')


def gg(request):
    return HttpResponse("sunkman")


def login(request):
    return render(request, 'login.html', locals())


def main(request):  # 判断id和密码，符合就进入主页，否则继续登录
    if request.method == 'POST':
        name = request.POST.get('name', "")
        password = request.POST.get('password', "")
        u = user.objects.filter(uname=name)
        if u and u[0].upassword == password:  # 合法的用户
            User = request.session.get('User', "null")
            User = name
            request.session['User'] = User
            u = user.objects.get(uname=User)
            return render(request, 'main.html', {"info": u})
        else:
            tips = "用户名或密码错误，请重试！"
            return render(request, 'login.html', locals())
    User=request.session['User']
    u=user.objects.get(uname=User)
    return render(request, 'main.html', locals())


def register(request):
    return render(request, 'register.html')


def myinfo(request):
    User = request.session.get('User')
    r = user.objects.get(uname=User)
    rid = r.id
    rname = r.uname
    rgender = r.ugender
    rlevel = r.ulevel
    rage = r.uage
    rphoto = r.uphoto
    rexp = r.uexp
    remail = r.uemail
    rintro = r.uintroduce
    rforbidden = r.isForbidden
    rlimit = 90 + 10 * rlevel
    postlist = post.objects.filter(puser_id=rid)
    if rgender == 1:
        rgender = "男"
    else:
        rgender = "女"
    if rforbidden == True:
        rforbidden = "由于您的不良行为，您已被禁止发帖，评论"
    else:
        rforbidden = "允许发帖，评论"
    return render(request, 'myinfo.html', locals())


def judgeinfo(request):  # 判断注册信息是否合法
    name = request.POST.get('name')
    email = request.POST.get('email')
    gender = request.POST.get('gender')
    age = request.POST.get('age')
    password = request.POST.get('password')
    repassword = request.POST.get('repassword')
    if user.objects.filter(uname=name).count():  # 不为0
        tips = "用户名已存在，请更改用户名！"
        return render(request, 'register.html', locals())
    elif not iflegalpasswd(password):
        tips = "密码必须不少于8位，并且至少同时含有字母和数字！"
        return render(request, 'register.html', locals())
    else:

        u = user()
        u.uname = name
        u.uage = age
        u.upassword = password
        u.ugender = gender
        u.uemail = email
        u.save()
        return HttpResponse("注册成功！")


def changeinfo(request):
    User = request.session.get('User')
    r = user.objects.get(uname=User)
    rname = r.uname
    rgender = r.ugender
    rlevel = r.ulevel
    rage = r.uage
    rexp = r.uexp
    remail = r.uemail
    rintro = r.uintroduce
    rforbidden = r.isForbidden
    rlimit = 90 + 10 * rlevel
    if rgender == 1:
        rgender = "男"
        xb = True
    else:
        rgender = "女"
        xb = False
    if rforbidden == True:
        rforbidden = "由于您的不良行为，您已被禁止发帖，评论"
    else:
        rforbidden = "允许发帖，评论"
    return render(request, 'changeinfo.html', locals())


def mainjudgeinfo(request):
    imagefile = request.FILES.get('photo', None)
    newname = request.POST.get('name')
    age = request.POST.get('age')
    gender = request.POST.get('gender')
    intro = request.POST.get('intro')
    email = request.POST.get('email')
    name = request.session.get('User')
    if name != newname and user.objects.filter(uname=newname):
        tips = "用户名" + '"' + newname + '"' + "已存在！"
        return render(request, 'changeinfo.html', locals())
    u = user.objects.get(uname=name)  # 更改信息
    u.uname = newname
    u.uemail = email
    u.uage = age
    u.ugender = gender
    if imagefile is not None:
        # f = open(os.path.join(up + "\\uphoto", imagefile.name), 'wb+')
        # for chunk in imagefile.chunks():
        #     f.write(chunk)
        # f.close()
        if (u.uphoto != "uphoto/default.jpg"):
            u.uphoto.delete()
        u.uphoto = imagefile
    u.uintroduce = intro
    u.save()
    request.session['User'] = newname  # 更新session
    r = user.objects.get(uname=newname)
    rname = r.uname
    rgender = r.ugender
    rlevel = r.ulevel
    rexp = r.uexp
    rage = r.uage
    remail = r.uemail
    rintro = r.uintroduce
    rforbidden = r.isForbidden
    rlimit = 90 + 10 * rlevel
    if rgender == 1:
        rgender = "男"
    else:
        rgender = "女"
    if rforbidden == True:
        rforbidden = "由于您的不良行为，您已被禁止发帖，评论"
    else:
        rforbidden = "允许发帖，评论"
    return render(request, 'myinfo.html', locals())


def changepassword(request):
    return render(request, 'changepassword.html')


def iflegalpasswd(string):
    a = False
    b = False
    d = False
    for c in string:
        if c.isalpha():
            a = True
        if c.isnumeric():
            b = True
    if len(string) >= 8:
        d = True
    return a and b and d


def judgepassword(request):
    oldpassword = request.POST.get('oldpassword')
    newpassword = request.POST.get('newpassword')
    renewpassword = request.POST.get('renewpassword')
    name = request.session.get('User')
    u = user.objects.get(uname=name)
    if u.upassword != oldpassword:
        tips = "原密码输入错误，请重试！"
        return render(request, 'changepassword.html', locals())
    elif not iflegalpasswd(newpassword):
        tips = "密码必须不少于8位，并且至少同时含有字母和数字！"
        return render(request, 'changepassword.html', locals())
    elif newpassword != renewpassword:
        tips = "新密码和确认密码必须相等！"
        return render(request, 'changepassword.html', locals())
    else:
        u.upassword = newpassword
        u.save()
        return HttpResponse("密码修改成功，请重新登陆！")


def discussarea(request):  # 讨论区界面，需要显示帖子
    name = request.session.get('User')
    u = user.objects.get(uname=name)
    i = 0
    postlist = post.objects.filter(ptype="discuss")
    return render(request, 'discussarea.html', locals())


def dispost(request):  # 讨论区发帖界面
    return render(request, 'dispost.html')


def filetype(filename):
    pos = len(filename)
    while pos >= 0:
        pos -= 1
        if filename[pos] == '.':
            break;
    type = filename[pos + 1:]
    if type.lower() == "mp4" or type.lower() == "avi" or type.lower() == "asf" or type.lower() == "rm" or type.lower() == "navi":
        return "video"
    else:
        return "picture"


def disjudgepost(request):
    file = request.FILES.getlist('file', None)
    title = request.POST.get('title')
    body = request.POST.get('body')
    r = post()
    r.ptitle = title
    r.pcontend = body
    r.ptype = "discuss"
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    r.puser_id = u.id
    r.save()
    for i in file:
        q = postphoto()
        q.photo = i
        q.post_id = r.id
        fn = str(i)
        q.ptype = filetype(fn)
        q.save()
    return HttpResponse('发布成功')


def viewpost(request, pid):
    name = request.session.get('User')
    u = user.objects.get(uname=name)
    po = post.objects.get(id=pid)
    photolist = postphoto.objects.filter(post_id=po.id)
    commentlist = comment.objects.filter(cpost_id=pid)
    return render(request, 'viewpost.html', locals())


def subjectarea(request):
    subjectlist = subject.objects.all()
    postlist = post.objects.filter(ptype="subject")
    return render(request, 'subject.html', locals())


def viewsubject(request, sid):
    sub = subject.objects.get(id=sid)
    return render(request, 'viewsubject.html', locals())


def like(request):
    uid = request.GET.get('uid')
    pid = request.GET.get('pid')
    po = post.objects.get(id=pid)
    op = {}
    if thumbup.objects.filter(user_id=uid).filter(post_id=pid):
        op['status'] = 'ever'
        op['num'] = po.pprasingnum
        op['tip'] = "您已经点过赞了！"
        return JsonResponse(op)
    else:
        t = thumbup()
        t.post_id = pid
        t.user_id = uid
        t.save()
        po.pprasingnum += 1
        po.save()
        op['status'] = 'success'
        op['num'] = po.pprasingnum
        op['tip'] = "点赞成功"
        return JsonResponse(op)


def tocomment(request):
    uid = request.GET.get('uid')
    pid = request.GET.get('pid')
    po = post.objects.get(id=pid)
    contend = request.GET.get('contend')
    comm = comment()
    comm.cuser_id = uid
    comm.cpost_id = pid
    comm.ccontend = contend
    comm.save()
    po.pcommentnum += 1
    po.save()
    op = {}
    op['status'] = 'success'
    op['tip'] = "评论成功"
    return JsonResponse(op)


def share(request):
    return render(request, 'share.html', locals())


def upload(request):
    sta = 0
    return render(request, 'uploadfile.html', locals())


def savefile(request):
    filename = request.POST.get('filename', "")
    filepath = request.POST.get('filepath', "")
    file = request.FILES.get('file', None)
    uname = request.session.get('User')
    u = user.objects.get(uname=uname)
    if filename == "" or (filepath == "" and file is None):
        tips = "文件名必须填写，文件地址和文件上传不能同时为空！"
        sta = 2
        return render(request, 'uploadfile.html', locals())
    if sharefile.objects.filter(suser_id=u.id).filter(filename=filename):
        tips = "你已经上传过同名文件，请更改文件名重新上传"
        sta = 2
        return render(request, 'uploadfile.html', locals())
    sf = sharefile()
    sf.filename = filename
    sf.filepath = filepath
    sf.file = file
    sf.suser = u
    sf.fuploadtime = datetime.now()
    sf.save()
    tips = "上传成功，你可以继续上传！"
    sta = 1
    return render(request, 'uploadfile.html', locals())


def filesearchtip(request):
    key = request.GET.get('key')
    tips = {}
    qset = sharefile.objects.filter(filename__icontains=key)
    nameset = []
    for i in qset:
        nameset.append(i.filename)
    tips['res'] = ','.join([str(i) for i in nameset])
    tips['status'] = 'success'
    return JsonResponse(tips)


def searchfile(request):
    key = request.POST.get('key')
    filelist = sharefile.objects.filter(filename__icontains=key)  # i代表忽略大小写
    return render(request, 'share.html', locals())


def downloadfile(request, fid):
    f = sharefile.objects.get(id=fid)
    fpath = "D:\\02.png"
    fpath = str(MEDIA_ROOT) + "\\" + str(f.file).replace('/', "\\")
    # print(fpath)
    # filename = str(f.file)[10:]
    # print(filename)
    # f = open(fpath,'rb')
    # data = f.read()
    # f.close()
    # # 以下设置项是为了下载任意类型文件
    # response = HttpResponse(data, content_type='application/octet-stream')
    # response['Content-Disposition'] = 'attachment; filename=%s' % filename
    # print(response['Content-Disposition'])
    # return response
    return download_file(request, fpath)


def download_file(request, file_path):
    file_name = os.path.basename(file_path)
    if not os.path.isfile(file_path):
        return HttpResponse(file_name)

    def file_iterator(tar_file_path, chunk_size=512):
        with open(tar_file_path, mode='rb') as file:
            while True:
                content = file.read(chunk_size)
                if content:
                    yield content
                else:
                    break

    try:
        response = StreamingHttpResponse(file_iterator(file_path))
        response['Content-Type'] = 'application/octet-stream'
        response["Content-Disposition"] = "attachment; filename*=UTF-8''{}".format(escape_uri_path(file_name))
    except:
        return HttpResponse("Sorry but Not Found the File")

    return response
